-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.1.0 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando estructura para tabla integrador_cac.oradores
CREATE TABLE IF NOT EXISTS `oradores` (
  `id_orador` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `apellido` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `mail` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `tema` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id_orador`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla integrador_cac.oradores: ~0 rows (aproximadamente)
INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `fecha_alta`) VALUES
	(1, 'Juan', 'Fonseca', 'juanfonseca@gmail.com', 'Tema 1', '2023-11-12 02:03:17'),
	(2, 'Gabriel', 'Gonzalez', 'gabygonzalez@gmail.com', 'Tema 2', '2023-11-12 02:03:25'),
	(3, 'Adriana', 'Monetti', 'adrimonetti@hotmail.com', 'Tema 3', '2023-11-12 02:03:25'),
	(4, 'Laura', 'Rossi', 'laurossi@yahoo.com.ar', 'Tema 4', '2023-11-12 02:03:25'),
	(6, 'Adolfo', 'Perez', 'adolfoperez@gmail.com', 'Tema 5', '2023-11-12 02:05:20'),
	(7, 'Gustavo', 'Sosa', 'gussosa@hotmail.com', 'Tema 6', '2023-11-12 02:05:20'),
	(8, 'Antonella', 'Giardino', 'antogiardino@gmail.com', 'Tema 7', '2023-11-12 02:05:20'),
	(9, 'Florencia', 'Pierucci', 'florperucci@yahoo.com.ar', 'Tema 8', '2023-11-12 02:05:20'),
	(10, 'Diego', 'Lopez', 'diegoalopez@gmail.com', 'Tema 9', '2023-11-12 02:05:20'),
	(11, 'Marina', 'Paz', 'marpaz@hotmail.com', 'Tema 10', '2023-11-12 02:05:20');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
